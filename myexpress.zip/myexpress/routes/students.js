var express = require('express');
var router = express.Router();
const mysql = require('mysql');
/* GET home page. */
// 连接mysql
var connection = mysql.createConnection({
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: '12345678',
    database: 'studentDate',
});
//渲染数据
router.get('/getStudent', function (req, res, next) {
    let sql = 'SELECT * FROM students';
    connection.query(sql, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(JSON.stringify(result));
        }
    });
});

//增加数据
router.post('/addStudent', function (req, res, next) {
    var response = {
        'studentid': req.body.params.studentid,
        'studentnumber': req.body.params.studentnumber,
        'age': req.body.params.studentage,
        'gender': req.body.params.studentgender,
        'name': req.body.params.studentname,
    };
    let addSqlParams = [response.studentid, response.studentnumber, response.age, response.gender, response.name];
    let addsql = 'INSERT INTO students(studentid,studentnumber,age,gender,name) value(?,?,?,?,?)';
    console.log(addSqlParams);
    connection.query(addsql, addSqlParams, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            console.log(result);
            res.send(result)
        }
    });
});
//删除
router.post('/removeStudent', function (req, res, next) {
    let _id = req.body.params.studentid;
    let sql = `DELETE FROM students WHERE studentid=${_id}`;
    connection.query(sql, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            console.log(result);
            res.send('删除成功');
        }
    })
});
// 修改,点击修改获取到的数据传送到另一个输入框
router.post('/updateStudent', function (req, res, next) {
    let date_id = req.body.params.updataStu;
    let sql = `SELECT * FROM students WHERE studentid=${date_id}`;
    connection.query(sql, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(JSON.stringify(result));
        }
    });
});
router.post('/upStudent', function (req, res, next) {
    var response = {
        'studentid': req.body.params.studentid,
        'studentnumber': req.body.params.studentnumber,
        'age': req.body.params.studentage,
        'gender': req.body.params.studentgender,
        'studentname': req.body.params.studentname,
    };
    console.log(response);
    let sql = `UPDATE students SET studentnumber=${response.studentnumber},age=${response.age},gender='${response.gender}',name='${response.studentname}' where studentid=${response.studentid}`;
    connection.query(sql, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            console.log(result);
            res.send(`update ${req.params.studentid} success`);
        }
    })
});

// 搜索
router.post('/getSeastudent', function (req, res, next) {
    let sql = `SELECT * FROM students WHERE studentid = ${req.body.params.Value_id}`;
    console.log(sql);
    connection.query(sql, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(JSON.stringify(result));
            console.log(result);
        }
    })
});
module.exports = router;