var express = require('express');
var router = express.Router();
const mysql = require('mysql');
const bcryptjs = require('bcryptjs');
/* GET users listing. */
var express = require('express');
const {
  json
} = require('express/lib/response');
// 后端理由,用于分配前端路由
var router = express.Router();
//连接mysql
  /* 
    host:连接的数据库地址
    port:连接地址对应的端口,默认3306
    user:mysql的连接用户名
    password:对应用户的密码
    database:所需要连接的数据库名称
    */
var connection = mysql.createConnection({
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: '12345678',
  database: 'studentDate',
});
// 登录
router.post('/login', function (req, res, next) {
  // 1.接受前端发送的数据,根据请求类型
  //  post:req.body
  //  get:req.query
  connection.connect();
  // 获得前端传递过来的参数
  var response = {
    "username": req.body.params.username,
    "password": req.body.params.password
  };
  // 根据用户名查询对应的密码，进行登录验证
  var sql = "SELECT password FROM user WHERE username=(?)";
  var sqlParam = [response.username,response.password];
  console.log(sqlParam);
  // 根据用户名查询对应密码进行验证
  connection.query(sql, sqlParam, function (err, result) {
    if (err) {
      console.log('[SELECT ERROR] - ', err.message);
      res.send(err);
      return;
    }
    if (result.length === 0) {
      // 用户名不存在
      res.send("1");
    } else {
      // 判断密码是否相等
      var isEqual = bcryptjs.compareSync(response.password, result[0].password);
      console.log(isEqual);
      res.send(isEqual);
    }
  });
  connection.end();
});

// 注册
router.post('/reg', function (req, res, next) {
  // 开始连接
  connection.connect();
  var response = {
    "username": req.body.params.username,
    "password": req.body.params.password
  };
  // 加密
  const SALT_FACTOR = 10;
  // 加密后的密码存入数据库中
  const password = bcryptjs.hashSync(response.password, bcryptjs.genSaltSync(SALT_FACTOR));
  var sql = "SELECT password FROM user WHERE username=(?)";
  var sqlParam = [response.username];
  /*
  根据用户名查询数据库查找是否已经存在重复用户名
  sql参数需要执行的sql语句,err回调函数执行sql语句的结果
  */
  connection.query(sql, sqlParam, function (err, result) {
    if (err) {
      console.log('[SELECT ERROR] - ', err.message);
      return;
    }
    if (result.length == 0) {
      // 用户名不存在
      // 插入新的用户名和密码数据
      var addSql = 'INSERT INTO user(username,password) VALUES(?,?)';
      var addSqlParams = [response.username,password];
      //添加
      connection.query(addSql, addSqlParams, function (err, result) {
        if (err) {
          console.log('[INSERT ERROR] - ', err.message);
          return;
        }
        console.log(result);
        // 将结果返回给前端
        res.send(result);
      });
    } else {
      // 用户名存在
      res.send('1');
    }
  })
});
module.exports = router;